"""Generated Python bindings for MoonBit packages.

This package is written by MoonBridge. Do not edit by hand.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Sequence

from ._runtime import (
    MoonError,
    MoonObject,
    MoonPanic,
    MoonStateError,
    Runtime,
    default,
    set_default,
)

__all__ = [
    "MoonError",
    "MoonObject",
    "MoonPanic",
    "MoonStateError",
    "Runtime",
    "default",
    "install",
    "open_guest",
    "run_batch",
    "set_default",
]


#: Name of the wasm binary inside the installed package.
_GUEST_FILE = "_guest.wasm"


def open_guest(wasm: str | Path | None = None) -> tuple[object, Runtime]:
    """Loads the guest module this package ships and returns its host.

    The wheel carries the wasm binary next to this file, so a caller who
    installed the package has nothing to configure. `wasm` overrides it for
    a build that wants to test a freshly compiled guest against an installed
    binding.
    """
    from . import _wasmtime

    path = Path(wasm) if wasm is not None else Path(__file__).with_name(_GUEST_FILE)
    host, runtime = _wasmtime.open_runtime(path)
    return host, runtime


def install(wasm: str | Path | None = None) -> tuple[object, Runtime]:
    """Loads the guest and makes it the one every generated module calls.

    This is the whole setup a user needs:

        host, runtime = moonbridge.install()
        from moonbridge import moonbitlang__core__json as json_ffi
    """
    host, runtime = open_guest(wasm)
    set_default(runtime)
    return host, runtime


def run_batch(
    symbol: str,
    calls: Sequence[Sequence[object]],
    *,
    wrap: Callable[[Any], Any] | None = None,
) -> list[Any]:
    """Runs N calls to one MoonBit symbol in a single boundary crossing.

    This is the low-level form. Generated modules wrap it as ``<fn>_many``
    so a caller gets typed results and automatic handle ownership; use that
    when the function returns a MoonBit object. `wrap` is the adapter those
    companions pass, and `symbol` is the qualified MoonBit name the module
    sends (``<package>::<function>``).
    """
    return default().request_many(symbol, calls, wrap)
